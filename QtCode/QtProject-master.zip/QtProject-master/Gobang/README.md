# C++ QT項目-五子棋(含AI對戰)

- Qt版本為5.14.2
- 使用的是MinGW編譯器
- 我寫的博客:https://blog.csdn.net/ngiokweng/article/details/118734116
- 視頻教程:https://www.bilibili.com/video/BV1ZK4y1G7Am?p=10&spm_id_from=pageDriver
