# Qt的各種項目
> 有任何問題可在 [我的論壇](http://macaucode.freecluster.eu/forum.php?mod=forumdisplay&fid=43) 提問
### 項目列表
__路徑中絕對不可以出現中文__
- [翻金幣項目](https://github.com/ngiokweng/QtProject/tree/master/CoinFlip)
- [計數器項目](https://github.com/ngiokweng/QtProject/tree/master/Calculator)
- [五子棋項目(含AI對戰)](https://github.com/ngiokweng/QtProject/tree/master/Gobang)
- [貪食蛇項目](https://github.com/ngiokweng/QtProject/tree/master/Snake)
- [重複文件檢測工具](https://github.com/ngiokweng/QtProject/tree/master/CheckFileRepeat)
