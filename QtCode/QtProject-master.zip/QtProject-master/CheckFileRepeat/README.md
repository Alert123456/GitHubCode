# C++ QT重複文件檢測工具

- Qt版本為5.14.2

- 使用的是MinGW編譯器

- 教學影片(別人):https://www.bilibili.com/video/BV14t411b7EL?p=5

  
