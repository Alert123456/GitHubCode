#include "value.h"

Value::Value(QString oper,double value)
{
    this->oper = oper;
    this->value = value;
}
