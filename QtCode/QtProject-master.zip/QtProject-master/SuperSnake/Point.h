#ifndef POINT_H
#define POINT_H


// 定義一個座標的結構體
struct Point{
    int x;
    int y;
};
#endif // POINT_H
