# C++ QT項目-翻金幣

- Qt版本為5.14.2
- 使用的是MinGW編譯器
- 其他資源中有詳細的教程文檔
- 視頻教程:https://www.bilibili.com/video/BV1g4411H78N?p=63
